l = [1,2,3,4,5,6,7,8,9,10]
print("All the elements in the list are: ")
for i in l:
    print(i)
print(l[4:8])
print(l*2)
l1 = [11,12,13]
print(l+l1)