t = (1,2,3,4,5,6,7,8,9,10)
print("All the elements in the tuple are: ")
for i in t:
    print(i)
print(t[7:9])
print(t*2)
t1 = ("Physics","Maths","Python")
print(t+t1)