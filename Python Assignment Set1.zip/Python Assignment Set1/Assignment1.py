
print("Enter the first number: ")
a = int(input())
print("Enter the first number: ")
b = int(input())
print("The sum of two numbers is: ", a+b)
print("The difference of two numbers is: ", abs(a-b))
print("The multiplication of two numbers is: ", a*b)
print("The division of first number by second is: ", a/b)