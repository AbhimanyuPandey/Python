print("Enter a number: ")
a = int(input())
if a%2==0:
    print("The number entered is even")
else:
    print("The number entered is odd")