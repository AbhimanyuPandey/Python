s = input()
for i in s:
    print(i)
print(s[3:7])
print(s*100)
s1 = input()
print(s+s1)